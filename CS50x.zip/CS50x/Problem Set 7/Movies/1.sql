SELECT title FROM movies
where year = 2008;